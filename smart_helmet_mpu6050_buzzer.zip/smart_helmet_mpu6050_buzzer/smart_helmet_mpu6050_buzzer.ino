#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>

// Ganti dengan SSID dan password WiFi kamu
const char *ssid = "Galaxy A33 5G14A";
const char *password = "ramw5936";

//Pin led
const int led_pin = 13;

//Pin Mpu
const int MPU = 0x68;

int16_t ax, ay, az;
int16_t lastAx=0, lastAy=0, lastAz=0;

// Pin buzzer
#define buzzer 25

// buzzer
int buzzerMode = 0;

// Inisialisasi server HTTP
WebServer server(80);

unsigned long lastToggle = 0;
bool buzzerState = false;
int interval = 200;
unsigned long startTime = 0;
bool counting = false;

void setup() {
  Serial.begin(115200);
  Wire.begin();
  Wire.beginTransmission(MPU);
  Wire.write(0x6B);
  Wire.write(0);
  Wire.setTimeout(50);
  Wire.endTransmission(true);

  // Setup pin motor sebagai OUTPUT
  pinMode(buzzer, OUTPUT);
  digitalWrite(buzzer, LOW);
  pinMode(led_pin, OUTPUT);
  digitalWrite(led_pin, LOW);

  // Hubungkan ke WiFi
  WiFi.begin(ssid, password);
  Serial.print("menghubungkan");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nterhubung ke WiFi");
  Serial.print("Alamat IP ESP32: ");
  Serial.println(WiFi.localIP());
  server.on("/led", handleLed);
  server.on("/on", handleOn);
  server.on("/off", handleOff);
  server.begin();
}

void loop() {
  server.handleClient();

  Wire.beginTransmission(MPU);
  Wire.write(0x3B);
  
  if (Wire.endTransmission(false) == 0){
    Wire.requestFrom(MPU, 6, true);
    if (Wire.available()==6){
      ax = Wire.read()<<8 | Wire.read();
      ay = Wire.read()<<8 | Wire.read();
      az = Wire.read()<<8 | Wire.read();

      lastAx=ax; lastAy=ay; lastAz=az;
    }
  } else {
    ax=lastAx; ay=lastAy; az=lastAz;
  }

  if (ax < -10000){
    if(!counting){
      startTime=millis();
      counting=true;
    }

    if(millis()-startTime>=3000){
      digitalWrite(led_pin, HIGH);

      if(ax < -13000)
        buzzerMode = 2;
      else
        buzzerMode = 0;
    }
    else{
      digitalWrite(led_pin,LOW);
      digitalWrite(buzzer,LOW);
    }
  }
  else{
    digitalWrite(led_pin,LOW);
    digitalWrite(buzzer,LOW);
    counting=false;
  }
  Serial.print("AX: "); Serial.print(ax);
  Serial.print(" AY: "); Serial.print(ay);
  Serial.print(" AZ: "); Serial.println(az);

  updateBuzzer();
}

void updateBuzzer(){
  static unsigned long last = 0;
  static bool state=false;

  if(buzzerMode==0){
    digitalWrite(buzzer,LOW);
    return;
  }

  if(buzzerMode==1){
    digitalWrite(buzzer,HIGH);
    return;
  }

  if(buzzerMode==2){
    if(millis()-last > 200){
      last = millis();
      state=!state;
      digitalWrite(buzzer,state);
    }
  }
}

void handleOn(){
  counting = false;
  buzzerMode = 2;
  server.send(200, "text/plain", "BUZZER ON");
}
 
void handleOff(){
  buzzerMode = 0;
  digitalWrite(led_pin, LOW);
  server.send(200, "text/plain", "ALL OFF");
}

void handleLed(){
  digitalWrite(led_pin, HIGH);
  server.send(200, "text/plain", "led");
}

